﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//using CustomExtensions;

namespace MaxFlowVisualization_Winforms {
    public partial class MainWindow : Form {
        private AppState appState;
        private MessageText message;

        // Algorithm:
        private MaxFlow maxFlow;
        private int numberOfNodesOnScreen;
        private int maxNumberOfNodes;
        private Label[] labelNodes;

        // Drawing:
        Graphics drawingArea;
        Point posInDrArea; // mouse position in drawing area coordinates, gets set everytime user clicks on drawing area in .Drawing mode
        private Pen pen;
        private float penWidth;
        private Color drawingColor;
        private int circleWidth;

        public MainWindow() {
            InitializeComponent();
            initializeOnStart();
        }

        private void initializeOnStart() {
            appState = AppState.Initialized;
            message = new MessageText();

            // drawing:
            drawingArea = DrawingAreaComponent.CreateGraphics();
            circleWidth = 15;
            penWidth = 2F;
            drawingColor = Color.DarkBlue;
            pen = new Pen(drawingColor, penWidth);

            // algorithm:
            maxFlow = new MaxFlow();
            resetGraph();
        }

        //                          LABEL NODES:

        private void initializeLabelArray(int dimension) {
            labelNodes = new Label[dimension];
        }

        private void addLabelNodeInArray(Label label) {
            this.labelNodes[numberOfNodesOnScreen] = label;
            numberOfNodesOnScreen++;
        }

        private void addNodeLabel(int index) {
            if (numberOfNodesOnScreen >= maxNumberOfNodes)
                return;
            // gets executed only when the number of nodes of screen is smaller than the max number of nodes

            // Add label:
            Label newLabel = new Label();

            newLabel.Location = getLabelNodeLocation(posInDrArea);
            newLabel.Name = "label_" + index.ToString();
            newLabel.Size = new Size(circleWidth, circleWidth); // size should be as big as the circle, since we will be draging it later
            newLabel.ForeColor = drawingColor;
            newLabel.Text = index.ToString();

            this.Controls.Add(newLabel);
            newLabel.BringToFront();

            // Add label to array:
            addLabelNodeInArray(newLabel);

            // Draw circle around the label:
            Point circlePos = new Point(posInDrArea.X - circleWidth, posInDrArea.Y - circleWidth);
            Size circleSize = new Size(circleWidth * 2, circleWidth * 2);
            drawingArea.DrawEllipse(pen, rect: new Rectangle(circlePos, circleSize));
        }

        private void removeLabelNodes()  {
            //foreach (Label labelNode in labelNodes)
            //TODO: erase label
            initializeLabelArray(0); // empty array of labels
        }

        /// <summary>
        /// Resets all properties associated with computing max flow - graph's dimension, number of current vertices etc.
        /// </summary>
        private void resetGraph() {
            numberOfNodesOnScreen = 0;
            maxFlow.ResetAllProperties();
        }

        private void showExample() {

        }

        private void solveCurrentExample() {

        }

        private void updateMessage() {
            labelMainMessage.Text = message.getAppropriateMessage(appState);
        }

        private void enableSolveButton(bool shouldEnable) {
            buttonSolve.Enabled = shouldEnable;
        }

        private void enableEndDrawingButton(bool shouldEnable) {
            //TODO: Should only get enabled when the drawn graph is actually a network!
            buttonSolve.Enabled = shouldEnable;
        }

        /// <summary>
        /// Responds to button clicks etc. depending on the state the app is at.
        /// </summary>
        private void processUserInput() {
            switch (appState) {
                case AppState.Initialized:
                    //TODO
                    break;
                case AppState.ShowExample:
                    showExample();
                    enableSolveButton(true);
                    break;
                case AppState.Solve:
                    enableSolveButton(false); // user should be able to invoke this method only once
                    solveCurrentExample();
                    break;
                case AppState.Draw:
                    enableSolveButton(false);
                    showEntryBox();
                    //TODO in the method: change the message to say
                    break;
                case AppState.EndDrawing:
                    enableSolveButton(true);
                    break;
                case AppState.Drawing:
                    addNodeLabel(numberOfNodesOnScreen);
                    enableSolveButton(false);
                    break;
                case AppState.ClearDrawingArea:
                    enableSolveButton(false);
                    cleanDrawingArea();
                    break;
                default:
                    enableSolveButton(false);
                    break;
            }
        }

        ///                                          ENTRY FORM - asks the user for the number of nodes his network will have:

        private void showEntryBox() {
            EnterNumberOfNodesForm entryForm = new EnterNumberOfNodesForm();

            if (entryForm.ShowDialog(this) == DialogResult.OK) { // shows the form and checks if user selected OK
                entryFormEntryConfirmed(entryForm.entryValue); 
            }
            entryForm.Dispose();
        }

        private void entryFormEntryConfirmed(int entryValue) {
            maxFlow.InitializeGraph(entryValue);
            initializeLabelArray(entryValue);
            maxNumberOfNodes = entryValue;
            appState = AppState.Drawing;
        }  

        ///                                          USER INPUT:

        private void buttonClicked() {
            updateMessage();
            processUserInput();
        }

        private void buttonDraw_Click(object sender, EventArgs e){
            appState = AppState.Draw;
            buttonClicked();
        }

        private void buttonShowExample_Click(object sender, EventArgs e) {
            appState = AppState.ShowExample;
            buttonClicked();
        }

        private void buttonClearDrawingArea_Click(object sender, EventArgs e) {
            appState = AppState.ClearDrawingArea;
            buttonClicked();
        }

        private void buttonEndDrawing_Click(object sender, EventArgs e) {
            appState = AppState.EndDrawing;
            buttonClicked();
        }

        private void buttonSolve_Click(object sender, EventArgs e) {
            appState = AppState.Solve;
            buttonClicked();
        }

        ///                                              DRAWING:

        private void DrawingAreaComponent_MouseDown(object sender, MouseEventArgs e) {
            posInDrArea = e.Location;
            processUserInput();
        }

        private Point getLabelNodeLocation(Point posInDrArea) {
            return new Point(posInDrArea.X + DrawingAreaComponent.Location.X - circleWidth / 3, posInDrArea.Y + DrawingAreaComponent.Location.Y - circleWidth / 3);
        }

        private void cleanDrawingArea() {
            removeLabelNodes();
            drawingArea.Clear(DrawingAreaComponent.BackColor);
        }
    }


    enum AppState {
        Initialized, ShowExample, Solve, Draw, Drawing, EndDrawing, ClearDrawingArea
    }


    /// <summary>
    /// Class storing and returning messages based on app state. 
    /// </summary>
    class MessageText {
        private const string defaultText = "Dodajte svoje omrežje z klikom na gumb Nariši omrežje ali poglej dani zgled";
        private const string showExampleText = "Izbrali ste možnost za prikaz primera.";
        private const string solveText = "Prosim počakajte dokler se reševanje primera ne dokonča.";
        private const string drawGraphText = "Izbrali ste možnost za risanje novega grafa.";
        private const string endDrawingText = "Če želite, da se animacija reševanja izvede, stisnite na gumb Reši zgled.";
        private const string drawingText = "Stisnite za dodajo novega vozlišča, povlečite med vozliščema za dodajo nove povezave.";
        private const string clearText = "Pobrisali ste risalno površino.";

        public string getAppropriateMessage(AppState appState) {
            switch (appState) {
                case AppState.Initialized:
                    return defaultText;
                case AppState.ShowExample:
                   return showExampleText;
                case AppState.Solve:
                    return solveText;
                case AppState.Draw:
                    return drawGraphText;
                case AppState.EndDrawing:
                    return endDrawingText;
                case AppState.Drawing:
                    return drawingText;
                case AppState.ClearDrawingArea:
                    return clearText;
                default:
                    return defaultText;
            }
        }
    }
}

/*
namespace CustomExtensions {
    public static class PointExtension {
        public static Point Add(Point A, Point B) {
            return new Point(A.X + B.X, A.Y + B.Y);
        }
    }
}
*/